# 🏠 Marketplace Poster — Magiore Imóveis

Automação de postagens de imóveis no Facebook Marketplace.
- Lê dados do Google Sheets
- Posta automaticamente 3x por dia
- Suporta imagens locais e URLs
- Atualiza status na planilha após cada postagem

---

## 📋 PRÉ-REQUISITOS

- Node.js 18+
- Conta do Facebook (com Marketplace ativo)
- Conta Google com Google Sheets API habilitada

---

## ⚙️ INSTALAÇÃO

```bash
cd marketplace-poster
npm install
cp .env.example .env
```

---

## 🔑 CONFIGURAÇÃO DO GOOGLE SHEETS

### 1. Criar Service Account

1. Acesse: https://console.cloud.google.com/
2. Crie um projeto (ou use um existente)
3. Ative a **Google Sheets API** em "APIs e Serviços"
4. Vá em "Credenciais" → "Criar Credenciais" → "Conta de Serviço"
5. Preencha o nome, clique em "Concluir"
6. Clique na conta criada → "Chaves" → "Adicionar Chave" → JSON
7. Salve o arquivo como `credentials.json` na pasta raiz do projeto

### 2. Compartilhar a Planilha

- Abra a planilha do Google Sheets
- Clique em "Compartilhar"
- Cole o e-mail da service account (ex: `nome@projeto.iam.gserviceaccount.com`)
- Permissão: **Editor**

---

## 📊 ESTRUTURA DA PLANILHA

Crie uma aba chamada **Imóveis** com estas colunas:

| Col | Campo         | Exemplo                                      |
|-----|---------------|----------------------------------------------|
| A   | ID            | `IM001`                                      |
| B   | Título        | `Casa 3 quartos com quintal - Sorocaba`       |
| C   | Descrição     | `Ótima localização, próximo ao centro...`    |
| D   | Preço         | `450000`                                     |
| E   | Tipo          | `Casa`, `Apartamento`, `Terreno`, `Comercial`|
| F   | Operação      | `Venda` ou `Aluguel`                         |
| G   | Quartos       | `3`                                          |
| H   | Banheiros     | `2`                                          |
| I   | Área          | `120`                                        |
| J   | Localização   | `Sorocaba, SP`                               |
| K   | Tags          | `casa, quintal, sorocaba, imóveis`           |
| L   | Imagens       | `C:\Fotos\casa1.jpg\|https://site.com/img.jpg` |
| M   | Status        | `pendente` (ou vazio = pendente)             |
| N   | Data Postagem | *(preenchido automaticamente)*               |
| O   | Link Postagem | *(preenchido automaticamente)*               |
| P   | Erro          | *(preenchido em caso de erro)*               |

> **Imagens:** separe múltiplas imagens com `|`
> Aceita caminhos locais (`C:\Fotos\img.jpg`) e URLs (`https://...`)

---

## 🔧 CONFIGURAÇÃO DO .ENV

```env
FB_EMAIL=seu@email.com
FB_SENHA=suaSenha

SHEET_ID=1aBcDeFgHiJkLmNoPqRsTuVwXyZ   # ID da URL da planilha
SHEET_ABA=Imóveis

DELAY_ENTRE_POSTS=120   # segundos entre postagens
MAX_POR_SESSAO=5        # imóveis por rodada

# Horários (padrão: 08h, 13h, 18h)
CRON_HORARIO_1=0 8 * * *
CRON_HORARIO_2=0 13 * * *
CRON_HORARIO_3=0 18 * * *

HEADLESS=false   # false = vê o navegador | true = invisível
```

---

## 🚀 USO

### Primeiro uso (configurar login)
```bash
npm run testar
```
Isso abre o Chrome. Faça login no Facebook manualmente se solicitado.
O perfil é salvo e você não precisará fazer login novamente.

### Modo agendado (recomendado)
```bash
npm start
```
Roda em background, posta nos horários configurados.

### Postar agora (manual)
```bash
npm run post-agora
```

---

## 📁 ESTRUTURA

```
marketplace-poster/
├── index.js              ← Entry point + scheduler
├── src/
│   ├── config.js         ← Todas as configurações
│   ├── logger.js         ← Logs
│   ├── sheets.js         ← Google Sheets (ler/atualizar)
│   ├── imageHandler.js   ← Imagens locais + URLs
│   ├── poster.js         ← Automação Puppeteer
│   └── test-login.js     ← Teste de login
├── credentials.json      ← Service account Google (criar)
├── .env                  ← Configurações (criar do .env.example)
├── chrome-profile/       ← Perfil Chrome salvo (criado automaticamente)
├── temp-images/          ← Imagens temporárias (criado automaticamente)
└── logs/
    ├── postagens.log
    ├── erros.log
    └── screenshots/      ← Screenshots de erro
```

---

## ⚠️ ATENÇÃO

- **Não poste mais de 5 imóveis por sessão** para evitar bloqueio
- **Delay mínimo de 2 minutos** entre postagens é recomendado
- O Facebook detecta automações — use `HEADLESS=false` nas primeiras semanas
- Se receber bloqueio: pause por 24h, reduza `MAX_POR_SESSAO` para 2-3

---

## 🔄 WORKFLOW COMPLETO

```
Google Sheets (status: pendente)
         ↓
    Puppeteer abre FB
         ↓
   Categoria: Imóveis
         ↓
   Upload das imagens
         ↓
  Preenche: título, preço,
  local, quartos, descrição
         ↓
       Publica
         ↓
Sheets atualiza: status=postado
```
